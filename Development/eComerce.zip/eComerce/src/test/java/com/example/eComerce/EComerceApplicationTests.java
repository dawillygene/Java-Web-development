package com.example.eComerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EComerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
