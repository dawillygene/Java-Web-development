package com.example.eComerce.Product;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class ProductConfig {
    @Bean
    CommandLineRunner runner(ProductRepository repository) {
        return args -> {
            Product product1 = new Product("Laptop", "High-performance laptop", 999.99, 10);
            Product product2 = new Product("Smartphone", "Latest model smartphone", 499.99, 20);
            repository.saveAll(List.of(product1, product2));
        };
    }
}